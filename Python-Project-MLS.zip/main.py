#########################################################################
#Title: PYTHON Project Scenario - Data Analysis
#Description: This program allows user to analyse.......
#Name: <Loy Zhen Da>
#Group Name: <MLS>
#Class: <PNK2004k>
#Date: <15Feb2021>
#Version: <3.0>
#########################################################################

#########################################################################
#IMPORT Pandas Library for Data Analysis
#########################################################################
#import pandas for data analysis
import pandas as pd
#########################################################################
#IMPORT Pandas Library for Data Analysis
########################################################################

#important matplot as pie chart
import matplotlib.pyplot as plt 
from collections import Counter

#########################################################################
#CLASS Branch - Data Analysis
#load excel data (CSV format) to dataframe
#########################################################################
class DataAnalysis:
  def __init__(self):

    #load excel data (CSV format) to dataframe - 'df'
    dataframe = pd.read_csv('MonthyVisitors.csv')
    #show specific country dataframe
    sortCountry(dataframe)
   
#########################################################################
#CLASS Branch: End of Code
#########################################################################

#########################################################################
#FUNCTION Branch - sortCountry
#parses data and displays sorted result(s)
#########################################################################
def sortCountry(df):


  #display the rows and columns 
  df= df.iloc[348:481,20:31]

  #initialise lists and variables
  visitor = []
  countries = []
  total_visitor = []
  visitor_dict = {}

  #appending countries and visitor to list
  for country in df.columns[0:11]:
    countries.append(country)
    for visitors in df[country]:
      visitor.append(visitors)
  for i in range(0,len(visitor)):
    visitor[i]=int(visitor[i])
  number_of_visitors = len(visitor)
  counter = number_of_visitors/len(countries)
  
  #convert string to integer to sum up
  Index1 = 0
  Index2= int(counter)
  #adds up the sum of visitor from the selected years in the country
  for i in range(0,(len(countries))):
    total_visitor.append(sum(visitor[Index1:Index2]))
    Index1=Index1+(int(counter))
    Index2=Index2+(int(counter))
  visitor_dict = {  countries[i]: total_visitor[i] for i in range(len(countries))}
  
  #sort visitor from highest to lowest , lamda is run code without provisioning or managing servers
  sort_visitor_dict = sorted(visitor_dict.items(), key=lambda x: x[1], reverse=True)
  visitor_dict=dict(sort_visitor_dict)
  df = pd.DataFrame(list(visitor_dict.items()),columns = ['Country','Visitors'])
###############################################################display top 3 country in piechart and output
##############################################################
  k=Counter(visitor_dict)
  top3= k.most_common(3)
  df= pd.DataFrame(top3,columns =['Country','Visitors'])
  print(df)
  labels=[]
  sizes=[]
  for i in df["Country"]:
    labels.append(i)
  for a in df["Visitors"]:
    sizes.append(a)
  distance = 0.1
  seperate = []
  for i in range(0,len(df['Country'])):
    seperate.append(distance)

###########################################################
#position to the best location and show the legend of the pie chart,to the 2.dp
###########################################################
  plt.pie(sizes,labels=labels,explode=seperate,autopct = '%1.2f%%',shadow = True)
  plt.axis('equal')
  plt.legend(loc='best')
  plt.show()
  
#########################################################################
#FUNCTION Branch: End of Code
#########################################################################

#########################################################################
#Main Branch
#########################################################################
if __name__ == '__main__':
  
  #Project Title
  print('######################################')
  print('# Data Analysis App - PYTHON Project #')
  print('######################################')


  #perform data analysis on specific excel (CSV) file
  DataAnalysis()

#########################################################################
#Main Branch: End of Code
#########################################################################